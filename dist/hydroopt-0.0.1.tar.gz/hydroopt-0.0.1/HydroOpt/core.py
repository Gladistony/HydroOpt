class TestePublicacao:
    def __init__(self):
        print("Iniciando classe de teste...")

    def testar(self):
        return "Sucesso! A biblioteca foi baixada do PyPI e está rodando."