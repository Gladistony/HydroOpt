import numpy as np


class Otimizador:
    """
    Classe para otimização de redes hidráulicas usando algoritmos de enxame.
    
    Detecta disponibilidade de GPU e permite ativá-la ou desativá-la manualmente.
    """
    
    def __init__(self, rede, usar_gpu=None, verbose=True):
        """
        Inicializa o Otimizador com uma rede hidráulica.
        
        Args:
            rede (Rede): Instância da classe Rede a ser otimizada
            usar_gpu (bool, optional): Se True força uso de GPU, False força CPU, None detecta automaticamente
            verbose (bool): Se True, exibe informações sobre configuração
        """
        from .rede import Rede
        
        # Validar rede
        if not isinstance(rede, Rede):
            raise TypeError("O parâmetro 'rede' deve ser uma instância da classe Rede.")
        
        self.rede = rede
        self.verbose = verbose
        
        # Detectar GPU disponível
        self.gpu_disponivel = self._detectar_gpu()
        
        # Definir modo de uso
        if usar_gpu is None:
            # Usar GPU se disponível
            self.usar_gpu = self.gpu_disponivel
        else:
            # Forçar modo especificado
            if usar_gpu and not self.gpu_disponivel:
                if self.verbose:
                    print("⚠️  GPU solicitada mas não disponível. Usando CPU.")
                self.usar_gpu = False
            else:
                self.usar_gpu = usar_gpu
        
        if self.verbose:
            self._exibir_configuracao()
    
    def _detectar_gpu(self):
        """
        Detecta a disponibilidade de GPU no sistema.
        
        Returns:
            bool: True se GPU está disponível, False caso contrário
        """
        try:
            import torch
            return torch.cuda.is_available()
        except ImportError:
            pass
        
        try:
            import cupy as cp
            cp.cuda.Device()
            return True
        except (ImportError, RuntimeError):
            pass
        
        return False
    
    def _exibir_configuracao(self):
        """Exibe informações sobre a configuração do otimizador."""
        print("\n" + "="*60)
        print("CONFIGURAÇÃO DO OTIMIZADOR")
        print("="*60)
        print(f"\nRede: {self.rede.nome}")
        print(f"GPU Disponível: {'Sim ✓' if self.gpu_disponivel else 'Não ✗'}")
        print(f"GPU em Uso: {'Sim ✓' if self.usar_gpu else 'Não (CPU)'}")
        print("\n" + "="*60 + "\n")
    
    def obter_status_gpu(self):
        """
        Retorna informações sobre o status da GPU.
        
        Returns:
            dict: Dicionário com status {'disponivel': bool, 'em_uso': bool}
        """
        return {
            'disponivel': self.gpu_disponivel,
            'em_uso': self.usar_gpu
        }
    
    def ativar_gpu(self):
        """
        Ativa o uso de GPU se estiver disponível.
        
        Returns:
            bool: True se GPU foi ativada, False se não disponível
        """
        if self.gpu_disponivel:
            self.usar_gpu = True
            if self.verbose:
                print("✓ GPU ativada com sucesso!")
            return True
        else:
            if self.verbose:
                print("⚠️  GPU não está disponível no sistema.")
            return False
    
    def desativar_gpu(self):
        """
        Desativa o uso de GPU (força execução em CPU).
        """
        self.usar_gpu = False
        if self.verbose:
            print("✓ GPU desativada. Usando CPU para cálculos.")
    
    def alternar_gpu(self):
        """
        Alterna entre usar GPU e CPU.
        
        Returns:
            bool: Estado atual (True = usando GPU, False = usando CPU)
        """
        if self.gpu_disponivel:
            self.usar_gpu = not self.usar_gpu
            status = "ativada" if self.usar_gpu else "desativada"
            if self.verbose:
                print(f"✓ GPU {status}.")
            return self.usar_gpu
        else:
            if self.verbose:
                print("⚠️  GPU não está disponível. Continuando com CPU.")
            return False
    
    def obter_rede(self):
        """
        Retorna a rede associada ao otimizador.
        
        Returns:
            Rede: Instância da rede
        """
        return self.rede
    
    def simular_rede(self):
        """
        Executa uma simulação da rede associada.
        
        Returns:
            dict: Resultado da simulação
        """
        if self.verbose:
            modo = "GPU" if self.usar_gpu else "CPU"
            print(f"\nExecutando simulação em {modo}...")
        
        return self.rede.simular()
    
    def obter_informacoes(self):
        """
        Retorna informações detalhadas do otimizador.
        
        Returns:
            dict: Dicionário com informações
        """
        return {
            'rede': self.rede.nome,
            'gpu_disponivel': self.gpu_disponivel,
            'gpu_em_uso': self.usar_gpu,
            'modo': 'GPU' if self.usar_gpu else 'CPU'
        }
