import numpy as np
import warnings


class Calculador:
    """
    Classe para gerenciar cálculos com suporte a GPU e CPU.
    
    Detecta automaticamente a disponibilidade de GPU no sistema e escolhe
    o melhor dispositivo de computação para executar operações numéricas.
    """
    
    def __init__(self, verbose=True):
        """
        Inicializa o Calculador e detecta recursos de computação disponíveis.
        
        Args:
            verbose (bool): Se True, exibe informações sobre os recursos detectados.
                           Default: True
        """
        self.verbose = verbose
        self.usa_gpu = False
        self.tipo_dispositivo = "CPU"
        self.info_gpu = {}
        
        # Tentar importar bibliotecas de GPU
        self._detectar_gpu()
        
        if self.verbose:
            self._exibir_informacoes()
    
    def _detectar_gpu(self):
        """
        Detecta a disponibilidade de GPU no sistema.
        
        Testa:
        - CUDA (NVIDIA)
        - cuDF (NVIDIA via RAPIDS)
        - PyTorch (suporta múltiplos backends)
        """
        print("Detectando recursos de computação...")
        
        # Teste 1: Verificar CUDA diretamente
        self._testar_cuda()
        
        # Teste 2: Verificar PyTorch
        if not self.usa_gpu:
            self._testar_pytorch()
        
        # Teste 3: Verificar CuPy (se PyTorch falhou)
        if not self.usa_gpu:
            self._testar_cupy()
        
        # Se nenhuma GPU foi detectada
        if not self.usa_gpu:
            self.tipo_dispositivo = "CPU"
            self.info_gpu = {"disponivel": False, "razao": "Nenhuma GPU detectada"}
            if self.verbose:
                print("⚠️  Nenhuma GPU disponível. Usando CPU para cálculos.")
    
    def _testar_cuda(self):
        """Testa disponibilidade de CUDA (NVIDIA)."""
        try:
            import torch
            if torch.cuda.is_available():
                self.usa_gpu = True
                self.tipo_dispositivo = "GPU (NVIDIA CUDA)"
                self.info_gpu = {
                    "disponivel": True,
                    "tipo": "NVIDIA CUDA",
                    "dispositivos": torch.cuda.device_count(),
                    "dispositivo_atual": torch.cuda.get_device_name(0),
                    "compute_capability": torch.cuda.get_device_capability(0),
                    "memoria_total_mb": torch.cuda.get_device_properties(0).total_memory / 1024**2
                }
                if self.verbose:
                    print(f"✓ NVIDIA CUDA detectado!")
                return
        except (ImportError, AttributeError, RuntimeError):
            pass
    
    def _testar_pytorch(self):
        """Testa suporte a GPU via PyTorch."""
        try:
            import torch
            
            # Verificar CUDA
            if torch.cuda.is_available():
                self.usa_gpu = True
                self.tipo_dispositivo = "GPU (PyTorch CUDA)"
                self.info_gpu = {
                    "disponivel": True,
                    "tipo": "PyTorch CUDA",
                    "dispositivos": torch.cuda.device_count(),
                    "dispositivo_atual": torch.cuda.get_device_name(0)
                }
                if self.verbose:
                    print(f"✓ PyTorch com CUDA detectado!")
                return
            
            # Verificar MPS (Apple Silicon)
            if torch.backends.mps.is_available():
                self.usa_gpu = True
                self.tipo_dispositivo = "GPU (Apple MPS)"
                self.info_gpu = {
                    "disponivel": True,
                    "tipo": "Apple Metal Performance Shaders (MPS)",
                    "backend": "PyTorch"
                }
                if self.verbose:
                    print(f"✓ Apple MPS (Metal Performance Shaders) detectado!")
                return
                
        except ImportError:
            pass
    
    def _testar_cupy(self):
        """Testa suporte a GPU via CuPy."""
        try:
            import cupy as cp
            
            # Testar se consegue acessar GPU
            cp.cuda.Device()
            
            self.usa_gpu = True
            self.tipo_dispositivo = "GPU (CuPy CUDA)"
            self.info_gpu = {
                "disponivel": True,
                "tipo": "CuPy CUDA",
                "dispositivos": cp.cuda.runtime.getDeviceCount()
            }
            if self.verbose:
                print(f"✓ CuPy com CUDA detectado!")
            return
            
        except (ImportError, RuntimeError):
            pass
    
    def _exibir_informacoes(self):
        """Exibe informações detalhadas sobre o dispositivo de computação."""
        print("\n" + "="*60)
        print("INFORMAÇÕES DO CALCULADOR")
        print("="*60)
        print(f"\nDispositivo: {self.tipo_dispositivo}")
        print(f"GPU Disponível: {'Sim ✓' if self.usa_gpu else 'Não ✗'}")
        
        if self.usa_gpu and self.info_gpu:
            print(f"\nDetalhes da GPU:")
            for chave, valor in self.info_gpu.items():
                if chave != "disponivel":
                    chave_formatada = chave.replace("_", " ").title()
                    print(f"  - {chave_formatada}: {valor}")
        
        print("\n" + "="*60 + "\n")
    
    def obter_tipo_dispositivo(self):
        """
        Retorna o tipo de dispositivo em uso.
        
        Returns:
            str: "CPU" ou "GPU (tipo)"
        """
        return self.tipo_dispositivo
    
    def obter_info_gpu(self):
        """
        Retorna informações detalhadas sobre a GPU.
        
        Returns:
            dict: Dicionário com informações da GPU ou vazio se não houver GPU
        """
        return self.info_gpu.copy()
    
    def usa_gpu_flag(self):
        """
        Retorna se GPU está sendo usada.
        
        Returns:
            bool: True se GPU está disponível, False caso contrário
        """
        return self.usa_gpu
    
    def matriz_aleatoria(self, forma, dtype=np.float32):
        """
        Cria uma matriz aleatória no dispositivo apropriado.
        
        Args:
            forma (tuple): Forma da matriz (ex: (1000, 1000))
            dtype: Tipo de dado (default: np.float32)
        
        Returns:
            array: Array numpy ou GPU array (dependendo do disponível)
        """
        try:
            if self.usa_gpu:
                import torch
                return torch.randn(forma, dtype=torch.float32)
            else:
                return np.random.randn(*forma).astype(dtype)
        except:
            return np.random.randn(*forma).astype(dtype)
    
    def multiplicacao_matrizes(self, matriz1, matriz2, usar_gpu=None):
        """
        Realiza multiplicação de matrizes usando o dispositivo disponível.
        
        Args:
            matriz1: Primeira matriz
            matriz2: Segunda matriz
            usar_gpu (bool, optional): Forçar uso de GPU/CPU. Se None, usa automático.
        
        Returns:
            array: Resultado da multiplicação
        """
        # Determinar se vai usar GPU
        usar_gpu_real = usar_gpu if usar_gpu is not None else self.usa_gpu
        
        try:
            if usar_gpu_real and self.usa_gpu:
                import torch
                
                # Converter para tensor se necessário
                if not isinstance(matriz1, torch.Tensor):
                    matriz1 = torch.from_numpy(matriz1)
                if not isinstance(matriz2, torch.Tensor):
                    matriz2 = torch.from_numpy(matriz2)
                
                # Mover para GPU
                matriz1 = matriz1.cuda()
                matriz2 = matriz2.cuda()
                
                # Operação
                resultado = torch.matmul(matriz1, matriz2)
                
                if self.verbose:
                    print(f"✓ Multiplicação executada em GPU")
                
                return resultado.cpu().numpy()
            else:
                # Usar CPU (NumPy)
                resultado = np.matmul(matriz1, matriz2)
                if self.verbose:
                    print(f"✓ Multiplicação executada em CPU")
                return resultado
                
        except Exception as e:
            if self.verbose:
                print(f"⚠️  Erro ao usar GPU, retornando para CPU: {str(e)}")
            return np.matmul(matriz1, matriz2)
    
    def somatorio(self, array, usar_gpu=None):
        """
        Calcula o somatório de um array.
        
        Args:
            array: Array NumPy
            usar_gpu (bool, optional): Forçar GPU/CPU
        
        Returns:
            float: Resultado do somatório
        """
        usar_gpu_real = usar_gpu if usar_gpu is not None else self.usa_gpu
        
        try:
            if usar_gpu_real and self.usa_gpu:
                import torch
                
                if not isinstance(array, torch.Tensor):
                    tensor = torch.from_numpy(array)
                else:
                    tensor = array
                
                tensor = tensor.cuda()
                resultado = tensor.sum().item()
                
                if self.verbose:
                    print(f"✓ Somatório executado em GPU")
                
                return resultado
            else:
                resultado = np.sum(array)
                if self.verbose:
                    print(f"✓ Somatório executado em CPU")
                return resultado
                
        except Exception as e:
            if self.verbose:
                print(f"⚠️  Erro ao usar GPU: {str(e)}")
            return np.sum(array)
    
    def executar_teste_performance(self, tamanho=1000):
        """
        Executa um teste de performance comparando CPU vs GPU.
        
        Args:
            tamanho (int): Tamanho das matrizes para teste (tamanho x tamanho)
        """
        import time
        
        print("\n" + "="*60)
        print("TESTE DE PERFORMANCE")
        print("="*60)
        print(f"\nTamanho das matrizes: {tamanho}x{tamanho}\n")
        
        # Criar matrizes de teste
        m1_cpu = np.random.randn(tamanho, tamanho).astype(np.float32)
        m2_cpu = np.random.randn(tamanho, tamanho).astype(np.float32)
        
        # Teste CPU
        print("Testando CPU...")
        inicio = time.time()
        resultado_cpu = np.matmul(m1_cpu, m2_cpu)
        tempo_cpu = time.time() - inicio
        print(f"  Tempo: {tempo_cpu:.4f}s")
        
        # Teste GPU (se disponível)
        if self.usa_gpu:
            print("\nTestando GPU...")
            try:
                import torch
                m1_gpu = torch.from_numpy(m1_cpu).cuda()
                m2_gpu = torch.from_numpy(m2_cpu).cuda()
                
                # Warm-up
                torch.matmul(m1_gpu, m2_gpu)
                
                # Teste real
                torch.cuda.synchronize()
                inicio = time.time()
                resultado_gpu = torch.matmul(m1_gpu, m2_gpu)
                torch.cuda.synchronize()
                tempo_gpu = time.time() - inicio
                
                print(f"  Tempo: {tempo_gpu:.4f}s")
                
                # Comparação
                speedup = tempo_cpu / tempo_gpu
                print(f"\nSpeedup GPU/CPU: {speedup:.2f}x")
                
            except Exception as e:
                print(f"  Erro ao executar teste em GPU: {e}")
        else:
            print("\nGPU não disponível para teste de performance")
        
        print("\n" + "="*60 + "\n")
